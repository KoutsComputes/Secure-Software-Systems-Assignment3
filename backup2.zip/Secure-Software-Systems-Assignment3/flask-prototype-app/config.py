DATABASE_URI = 'mysql+pymysql://username:password@localhost/db_name'
SECRET_KEY = 'your_secret_key'
DEBUG = True